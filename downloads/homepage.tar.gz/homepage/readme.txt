index.html											does not have any template
old.html											does not have any template
about.html											has 'empty container' as template
games.html											has 'empty container' as template

apple_shooter.html										has 'flash container' as template
pool.html											has 'flash container' as template
soccer.html											has 'flash container' as template
chess.html											has 'flash container' as template

Any modification to the internal workings has to be done to :
-> index.html
-> old.html
-> empty container.dwt
-> flash container.dwt

Google Analytics Tracking ID									UA-29848640-1